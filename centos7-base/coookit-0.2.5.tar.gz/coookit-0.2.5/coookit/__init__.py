__version__ = '0.2.5'
__description__ = 'Django project.  Space to share experience'