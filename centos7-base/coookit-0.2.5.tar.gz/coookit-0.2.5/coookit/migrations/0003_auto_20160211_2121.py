# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('coookit', '0002_auto_20160211_2057'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='articles',
            options={'ordering': ['-modified_date']},
        ),
        migrations.AddField(
            model_name='articles',
            name='publish',
            field=models.BooleanField(default=True, verbose_name=b'Public visibility'),
            preserve_default=True,
        ),
    ]
