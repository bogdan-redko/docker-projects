# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import tinymce.models
import easy_thumbnails.fields


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Articles',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('header', models.CharField(max_length=100, verbose_name=b'Header')),
                ('header_image', easy_thumbnails.fields.ThumbnailerImageField(upload_to=b'/uploads/', verbose_name=b'Image header')),
                ('thumbnail', easy_thumbnails.fields.ThumbnailerImageField(upload_to=b'/uploads/', verbose_name=b'Thumbnail')),
                ('negative_feedback', models.IntegerField(default=0, verbose_name=b'Negative Feedback count')),
                ('positive_feedback', models.IntegerField(default=0, verbose_name=b'Positive Feedback count')),
                ('article_type', models.CharField(default=b'M', max_length=2, verbose_name=b'Article type', choices=[(b'M', b'Monitoring'), (b'V', b'Visualizing'), (b'P', b'Provisioning'), (b'N', b'Networking'), (b'W', b'Web'), (b'D', b'Deployment'), (b'O', b'Other')])),
                ('content', tinymce.models.HTMLField(verbose_name=b'Article body')),
            ],
            options={
                'abstract': False,
            },
            bases=(models.Model,),
        ),
    ]
