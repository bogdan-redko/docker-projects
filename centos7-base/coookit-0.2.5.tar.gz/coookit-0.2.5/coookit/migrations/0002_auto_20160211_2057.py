# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import easy_thumbnails.fields


class Migration(migrations.Migration):

    dependencies = [
        ('coookit', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='articles',
            name='content',
            field=models.TextField(verbose_name=b'Article body'),
        ),
        migrations.AlterField(
            model_name='articles',
            name='header_image',
            field=easy_thumbnails.fields.ThumbnailerImageField(upload_to=b'uploads/', verbose_name=b'Image header'),
        ),
        migrations.AlterField(
            model_name='articles',
            name='thumbnail',
            field=easy_thumbnails.fields.ThumbnailerImageField(upload_to=b'uploads/', verbose_name=b'Thumbnail'),
        ),
    ]
